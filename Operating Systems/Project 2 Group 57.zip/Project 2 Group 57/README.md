# CSCI-4061-Project-2
## How to compile the program
- run "make" with the provided Makefile in the terminal within the directory containing the file autograder.c
- run "./autograder <ipc_type> <p1> <p2> ... <pn>, where ipc_type is the type of inter-process communication used and p1, p2 ... pn are the parameter inputs

## Assumptions
No assumptions were made outside of the ones in the writeup

## P2 Group 57

- Nicholas Haddad: hadda049
- Aiden Theiste: theis683
- Benjamin Ziebol: ziebo012

## Contributions

- Nicholas: Change D
- Aiden: Change B
- Benjamin: Change C