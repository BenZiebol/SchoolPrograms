# P3 Group 57
CSCI 4061 - Fall 2024 - Project #3
- Nicholas Haddad: hadda049
- Aiden Theiste: theis683
- Benjamin Ziebol: ziebo012
## Assumptions
No assumptions were made outside of the ones in the writeup

## CSELab machine
csel-vole-fx3node-prd-29

## Plan for individiual work
Nicholas:
Implement request_handle function
Implement image match

Aiden: 
Assign to the buffer from the database struct
LogPrettyPrint
Add the request into the queue

Ben: 
Get the request from the queue and do as follows
Call image_match with the request buffer and file size
Call LogPrettyPrint() to print server log

## Plan for constructing the worker threads and mutex
Constructing worker threads will need to done in the main function and we will have the workers doing/checking tasks (loop)
using mutex we can ensure that only task is added or removed as well as ensuring multiple workers don't mess up one another